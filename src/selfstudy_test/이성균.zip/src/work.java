import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

// 게임 결과를 출력하는 클래스
class ResultPrinter {
    public static void printResults(ArrayList<Integer> guesses, int answer) {
        System.out.println("입력한 숫자 목록:");
        for (int guess : guesses) {
            System.out.print(guess + " ");
        }
        System.out.println();

        if (guesses.get(guesses.size() - 1) == answer) {
            System.out.println("정답이야.");
        } else {
            System.out.println("틀렸어, 정답은 " + answer + " 이야.");
        }
    }

    public static void saveResultsToFile(ArrayList<Integer> guesses, int answer) {
        try {
            FileWriter writer = new FileWriter("game.txt"); //파일 쓰기를위한 FileWriter객체 생성
            writer.write("입력한 숫자 목록:\n");
            for (int guess : guesses) {//숫자목록과 숫자를 파일에 기록
                writer.write(guess + " ");
            }
            writer.write("\n");

            if (guesses.get(guesses.size() - 1) == answer) {
                writer.write("정답이야.\n");
            } else {
                writer.write("틀렸어, 정답은 " + answer + " 이야.\n");
            }//정답과 오답의 경우에 따라 결과 기록

            writer.close();
            System.out.println("결과가 game.txt 파일에 저장되었습니다.");
        } catch (IOException e) {
           //오류 발생시
        	System.out.println("파일 저장 중 오류가 발생했습니다.");
        }
    }
}

// 숫자 맞추기 게임을 진행하는 클래스
class NumberGuessingGame {
    private int answer;
    private ArrayList<Integer> guesses;

    public NumberGuessingGame() {
        Random random = new Random();    //숫자 생성을 위한 Random객체 생성
        answer = random.nextInt(10) + 1; //1부터 10 사이의 숫자 생성
        guesses = new ArrayList<>();     //숫자를 저장할 리스트 생성
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < 3; i++) { //최대 3번의기회를 가짐
            System.out.print("1부터 10까지 숫자를 입력하세요: ");
            int guess = scanner.nextInt(); //입력을 받아 추측한 숫자로 저장
            guesses.add(guess);   // 추측한 숫자를 리스트에추가

            if (guess == answer) {
                break; //맞춘경우 반복을 미리 종료
            } else if (guess < answer) {
                System.out.println("낮음");
            } else { //틀린경우 숫자가 더 낮거나 높음을 말해줌
                System.out.println("높음");
            }
        }

        ResultPrinter.printResults(guesses, answer);
        ResultPrinter.saveResultsToFile(guesses, answer);
    }  //결과를 출력,파일로 저장 해줌
}

// 메인 클래스
public class work {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("숫자 맞추기 게임을 시작합니다.");
            NumberGuessingGame game = new NumberGuessingGame(); //게임 객체 생성
            game.play(); //게임플레이

            System.out.print("계속하시겠습니까? (y/n): ");
            String input = scanner.next();
            if (!input.equalsIgnoreCase("y")) {
                break; //y가 아니면 반복 종료
            }
        }
    }
}
